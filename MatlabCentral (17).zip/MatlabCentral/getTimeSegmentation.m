%Seg: Segmentation
%C: distance matrix for segmentation
%Sig: given signal
%InitSeg: Initial segmentation
%acc: maximum distance of Seg from initial segmentation. Acc is related with search space

function [Seg,C] = getTimeSegmentation(Sig,InitSeg,acc)

choice = 1; % 1:corr  2:diff

toPlot = 1;

Seg = InitSeg;
N = size(Sig,2);
L = length(Seg);

C = sparse(N,N);

CA = zeros(N,N)-1;

%T = mean(diff(InitSeg));

for id1=1:L-1,
    T = InitSeg(id1+1)-InitSeg(id1);
    for t1=InitSeg(id1)-acc:InitSeg(id1)+acc,
        if id1 == 1,
            t1=InitSeg(id1);
        end
        for t2=InitSeg(id1+1)-acc:InitSeg(id1+1)+acc,

            if t1 <= 0 || t2 >= N-1,
                continue;
            end
           
            if choice == 2,
                CA(t1,t2) = 1000.0;
            end
            
            v = [t1:t2-1];
            k = 1;
            w = zeros(1,2*acc+1);
           % if t1 == 79 && t2 == 157,
           %     t2
           % end
            for dT=-acc:acc,
                if id1 == L - 1
                    alfa =  (InitSeg(id1)-InitSeg(id1-1)+dT)/ (length(v));
                else
                    alfa =  (InitSeg(id1+2)-InitSeg(id1+1)+dT)/ (length(v));
                end
                [vp,va] = getVP_VA(v,alfa);
                if id1 == L - 1 && vp(1) >= 1,
                    c = 0;
                    for i=1:size(Sig,1),
                        x = Sig(i,v);
                        %y = Sig(i,vp);
                        y = getSig(Sig,i,vp);
                        %c = c+corr(x',y');
                        c = c+getDiff(x',y',choice);
                    end
                    CA(t1,t2) = c/size(Sig,1);
                elseif id1 < L - 1 && va(length(v)) < N,
                    c = 0;
                    for i=1:size(Sig,1),
                        x = Sig(i,v);
                        %y = Sig(i,va);
                        y = getSig(Sig,i,va);
                        %c = c+corr(x',y');
                        c = c+getDiff(x',y',choice);
                    end
                    CA(t1,t2) = c/size(Sig,1);
                else
                    CA(t1,t2) = -1;
                end
                if choice == 1,
                    w(k) = 1.00001-CA(t1,t2);
                    k = k+1;
                else
                    w(k) = CA(t1,t2);
                    k = k+1;
                end
            end
            if k > 1,
                C(t1,t2) = min(w(1:k-1));
            end
        end
        if id1 == 1,
             break;
        end
    end
end

for i=InitSeg(L)-acc:InitSeg(L)+acc,
    C(i,N) = 0.0001;
end

[dist, path, pred]=graphshortestpath(C,InitSeg(1),N,'Directed','true');
%dist
1-(dist/(length(path)-1))
path
Seg = path(1:length(path)-1);

if toPlot == 1,
    for i=1:size(Sig,1),
        x = Sig(i,:);
        figure;
        v1 = min(x);
        v2 = max(x);
        for j=1:length(Seg),
            plot([Seg(j) Seg(j)],[v1 v2],'r--');
            hold on;
        end
        legend('Segments');
        hold on;
        plot(x,'k');
        xlabel('frames');
        ylabel('angle');
    end
end

function [d] = getDiff(x,y,choice)

c = choice;

if c == 1,%correlation 
    d = corr(x,y);
else
    d = abs(x-y);
    for k=-2:2,
        d = min(d,abs(2*k*pi+x-y));
    end
    d = mean(d);
end

function [vp,va] = getVP_VA(v,alfa)

L = length(v);

t1 = v(1);
t2 = v(L);
%-(t2-t1+1)
vp = alfa*[1:L]-alfa*L+t1-alfa;
va = alfa*[1:L]+t2;



function [y] = getSig(Sig,i,va)

L = length(va);
x = [floor(va(1)):ceil(va(L))]; 
y = Sig(i,x); 
xi = va; 
y = interp1(x,y,xi); 

