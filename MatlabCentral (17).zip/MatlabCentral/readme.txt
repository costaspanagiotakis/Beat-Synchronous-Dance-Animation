This code is a simple  implementation of Beat Synchronous Dance Animation based on Periodic Motion and Music Tempo Analysis
based on the paper [1]. It implements an audio Sychronization method. 

The goal of the proposed methods is to generate beat synchronous
dance animation (bvh format) based on the analysis of both visual and audio data.
 We proposeand employ a new method for the temporal segmentation of such motion
data into the periods of dance. Next, we use a beats of audio. Given an
input music with its beats that is of the same genre as the one corresponding to the
visually observed dance, we automatically produce a beat synchronous
dance animation of a virtual character. 
The proposed approach has been
validated with extensive experiments performed on a data set containing
a variety on traditional Greek/Cretan dances and the corresponding
music

You can find more details in www.csd.uoc.gr/~cpanag and http://users.ics.forth.gr/~argyros/

It uses the toolboxes 
MOCAP0p136 from  http://motor-invariant-control.googlecode.com/svn/trunk/BVH/MOCAP0p136/ 
and NDLUTIL0p162 from https://github.com/XinweiJiang/SLLGPLVM/tree/master/NDLUTIL0p162 

Files: 
   runClustering.m: implemetation of the method
  
We will appreciate if you cite our papers [1-2] in your work: 

 [1] C. Panagiotakis, Andre Holzapfel, Damien Michel, and Antonis Argyros, Beat Synchronous Dance Animation based on Periodic Motion and Music Tempo Analysis, International Symposium on Visual Computing, 2013.
 [2] C. Panagiotakis, Damien Michel, and Antonis Argyros, Temporal segmentation and seamless stitching of motion patterns for synthesizing novel animations of periodic dances, International Conference on Pattern Recognition, 2014.



