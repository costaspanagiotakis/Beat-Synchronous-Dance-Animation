function [Seg] = getInitSegMax(Sig,start,acc)
%Arxikopoihsh arxikhs tmhmatopoihshs

Seg(1) = start;
id = 2;
i=start;

while i < length(Sig)-acc,
    if max(Sig(i-acc:i+acc)) == Sig(i),
        Seg(id) = i;
        id = id+1;
        i = i+acc;
    end
    i = i+1;
end







