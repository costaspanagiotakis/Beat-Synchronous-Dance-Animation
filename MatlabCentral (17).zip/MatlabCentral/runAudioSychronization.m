%
% Audio Sychronization based on [1] 
%  [1] C. Panagiotakis, Andre Holzapfel, Damien Michel, and Antonis Argyros, Beat Synchronous Dance Animation based on Periodic Motion and Music Tempo Analysis, International Symposium on Visual Computing, 2013.


close all;
clear all;
addpath('NDLUTIL0p162','MOCAP0p136');

FILEBVH = 'data\siganos_sitiakes_1.bvh'; % 3D motion Data


FILEAUDIO = 'data\300_M_A30.wav'; %audio file for sync  
FILEBEATS = 'data\300_M_A30.txt'; %beats of audio file 

OUTBVHFILE = 'results\siganos_sitiakes_1_300_M_A30.bvh'; %3D motion output file  
OUTWAVFILE = 'results\siganos_sitiakes_1_300_M_A30.wav'; %audio output file

STEPS = 6;%Steps of periodic dance e.g. Siganos (6)

[SKEL, CHANNELS, FRAMELENGTH] = bvhReadFile(FILEBVH);
CHANNELS = smoothAngleChannels(CHANNELS,SKEL);
%skelPlayData(SKEL, CHANNELS, FRAMELENGTH);

N = size(CHANNELS,1);

NodesNames = cell(1,1);
NodesNames{1} = 'LeftHip';
NodesNames{2} = 'RightHip';
%NodesNames{2} = 'LeftKnee';
%NodesNames{3} = 'RightHip';
%NodesNames{4} = 'RightKnee';
INDEXES = [];
for i=1:length(NodesNames),
    k = skelReverseLookup(SKEL,NodesNames{i});
    INDEXES = [INDEXES SKEL.tree(k).rotInd];
end
Sig = CHANNELS(:,INDEXES)';

%InitSeg = getInitSegMax(Sig(1,:),100,acc);
InitSeg = [118 227 336  445 552 657  761 868 ]; %Initial segmentation 

acc = 1+round(0.1*mean(diff(InitSeg)));
[Segments,C] = getTimeSegmentation(Sig([1 4],:),InitSeg,acc);
Segments = InitSeg;
L = length(Segments);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Load audio file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[y, Fs] = audioread(FILEAUDIO);%original audio signal
beats = textread(FILEBEATS, '%f', 'delimiter', '\n'); %beats of audio signal in sec

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Sychronization with audio file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BeatsFrames = beats/FRAMELENGTH; %beats of audio signal in frames
AudioPeriodsFrames = BeatsFrames(1:STEPS:1+STEPS*(L-1));
timeApo = beats(1); %start time and end time of used audio signal 
timeEos = beats(1+STEPS*(L-1));
r = zeros(1,L-1);%oversampling rate
for i=1:L-1,
    r(i) = (Segments(i+1) - Segments(i)) / (AudioPeriodsFrames(i+1)-AudioPeriodsFrames(i));
end
NumFramesNew = floor(AudioPeriodsFrames(length(AudioPeriodsFrames)) - AudioPeriodsFrames(1));
NumFramesOld = Segments(L)-Segments(1);
CHANNELS_syn = zeros(NumFramesNew,size(CHANNELS,2));

t = zeros(1,NumFramesNew);
r_= zeros(1,NumFramesNew);
w = zeros(NumFramesNew,3);
d = (AudioPeriodsFrames(L) - AudioPeriodsFrames(1))/ (L-1);
t(1) = Segments(1);
for i=2:NumFramesNew,
    vec = sort([AudioPeriodsFrames(2:L-1)' i+AudioPeriodsFrames(1)]);
    pos = find(vec == i+AudioPeriodsFrames(1));
    pos = pos(1);
    for k=-1:1,
        if pos+k >= 1 && pos+k+1 <= L,
            temp = i+AudioPeriodsFrames(1)-mean([AudioPeriodsFrames(pos+k)   AudioPeriodsFrames(pos+k+1)]);
            w(i,k+2) = exp(-2*((temp/d)^2));
            r_(i) = r_(i)+w(i,k+2)*r(pos+k);
        end
    end
    r_(i) = r_(i) / sum(w(i,1:3));
    t(i) =  t(i-1)+r_(i);
end
r_(1) = r_(2);
%
for i=1:NumFramesNew,
    for j=1:size(CHANNELS,2),
        t1 = ceil(t(i));
        dt = t(i)-t1;
        w1 = 1-dt;
        a1 = CHANNELS(t1,j);
        a2 = CHANNELS(t1+1,j);
        CHANNELS_syn(i,j) = a1*w1+(1-w1)*a2;
    end
end

y_out = y(1+round(timeApo*Fs):1+round(timeEos*Fs),:);
bvhWriteFile(OUTBVHFILE, SKEL, CHANNELS_syn, FRAMELENGTH);
audiowrite(OUTWAVFILE,y_out, Fs);
%wavplay(y_out,Fs);

skelPlayData(SKEL, CHANNELS, FRAMELENGTH);









